# History
### 0.2.1
* bug fix : Multiple instances #4

### 0.2.0
* re-engineer project

### 0.1.0
* improved transforms
* added theme feature

### 0.0.9
* data-carousel-3d-left / data-carousel-3d-right notation has changed to data-carousel-3d-prev / data-carousel-3d-next

### 0.0.6
* improved IE8,9 transform.

### 0.0.5
* added 'select' event

### 0.0.4
* bug fix: not initialized on safari 8
